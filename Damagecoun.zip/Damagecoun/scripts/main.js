import { world, system } from "@minecraft/server";
import "./damageCount/script.js";

system.events.beforeWatchdogTerminate.subscribe((a) => {
  a.cancel = true;
});
world.events.worldInitialize.subscribe(() => {
	world.getDimension('overworld').runCommandAsync("say reload");
});
