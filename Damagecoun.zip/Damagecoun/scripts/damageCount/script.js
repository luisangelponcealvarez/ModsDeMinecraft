import { world, DynamicPropertiesDefinition, EntityTypes } from "@minecraft/server";

function find(array, txt) { for(let i=0;i<array.length;i++){ if(array[i].substring(0, txt.length)===txt){ return array[i] } }return txt };

async function  damageCount(entity, value){
	await entity.runCommandAsync(`summon gc:damage_count`);
	if(value>=0){
		entity.runCommandAsync(`event entity @e[c=1,type=gc:damage_count,tag=!pronto] gc:positive__0`);
		let txt = `-${Math.trunc(value)}`.split("");
		for(let i=1;i<txt.length;i++){ entity.runCommandAsync(`event entity @e[c=1,type=gc:damage_count,tag=!pronto] gc:damage_l${i}__${txt[i]}`); }
	}else{
		entity.runCommandAsync(`event entity @e[c=1,type=gc:damage_count,tag=!pronto] gc:positive__1`);
		let txt = `${Math.trunc(value)}`.split("");
		for(let i=1;i<txt.length;i++){ entity.runCommandAsync(`event entity @e[c=1,type=gc:damage_count,tag=!pronto] gc:damage_l${i}__${txt[i]}`); }
	}
	entity.runCommandAsync(`tag @e[c=1,type=gc:damage_count,tag=!pronto] add pronto`);
}

world.events.tick.subscribe(()=>{
  const entitys = Array.from(world.getDimension("overworld").getEntities());
	for(let entity of entitys) {
		if(entity.getComponent("minecraft:health")!==undefined){
			const entityHealth = Number(entity.getComponent("minecraft:health").current)
			const entityHealthTag= Number(find(entity.getTags(), "health").split(":")[1]||0)
			if(entityHealth!==entityHealthTag){
				entity.removeTag(find(entity.getTags(), "health"))
				entity.addTag(`health:${entityHealth}`)
				
				damageCount( entity, entityHealth-entityHealthTag )
			}
			//entity.runCommandAsync("say a");
		}
	}
});
