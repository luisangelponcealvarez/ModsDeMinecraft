import { world, BlockLocation, EntityQueryOptions } from "mojang-minecraft";
import { ActionFormData } from "mojang-minecraft-ui";


world.events.tick.subscribe(handler);

let activeCommand = false;
let firstTime = { activo: false };
let playerName = "";
let random = "";
let giveConfig = { "item_lock": { "mode": "lock_in_inventory" }, "keep_on_death": {} };

// Detector de Muerte y Resurreccion.
function handler() {
  let players = Array.from(world.getPlayers());
  let w = world.getDimension("overworld");
  for(let i = 0; i < players.length; i++){
    w.runCommand(`gamerule sendcommandfeedback false`);

    // Spawnear tumba y coordenadas.  
    if (players[i].getComponent("health").current == 0 && firstTime.activo == false) {
     firstTime.activo = true;
     playerName = players[i].name;
     players[i].runCommand(`tellraw @s {"rawtext":[{"translate":"action.players.death"},{"text":"${Math.floor(players[i].location.x)} ${Math.floor(players[i].location.y)} ${Math.floor(players[i].location.z)}"}]}`);
     players[i].runCommand(`execute @a[name="${players[i].name}"] ~~~ summon new:tumba ~~~ minecraft:entity_spawned "${players[i].name}"`);
     players[i].runCommand("execute @e[type=item,r=2.5] ~~1~ tp @s ~~-1~");
   }



   // Otorgar llave random.
   if (players[i].name == playerName && players[i].getComponent("health").current > 0 && firstTime.activo == true && random < 90) { 

      firstTime.activo = false; 
      players[i].runCommand(`give "${players[i].name}" new:key2 1 0 ${JSON.stringify(giveConfig)}`);    
      playerName = "";
      random = ""; 
   }
   if (players[i].name == playerName && players[i].getComponent("health").current > 0 && firstTime.activo == true && random >= 90) {

      firstTime.activo = false; 
      players[i].runCommand(`give "${players[i].name}" new:key 1 0 ${JSON.stringify(giveConfig)}`);    
      playerName = "";
      random = ""; 
   }

   //Detectar item en el inventario
   let p = players[i];
   let pInv = p.getComponent("inventory");
   let items = getItems(pInv.container);
   let itemSlot = findItem(items, { id: "new:key2", amount: '*' });
   let itemSlot2 = findItem(items, { id: "minecraft:ender_pearl", amount: '*' });
   if(itemSlot > -1 && itemSlot2 > -1){ 
     activeCommand = true;
   } 
   else if(itemSlot <= -1 || itemSlot2 <= -1){
     activeCommand = false;
   }
 }
}

//Tp a tumbas
world.events.beforeItemUse.subscribe(data => {
  var p = data.source;
  switch (data.item.id) {
    case "new:key": {
      p.runCommand(`tp @s @r[type=new:tumba,name="${p.name}"]`);
    } break;
    default:
    break;
  }
});


// Abrir tumba por el dueño
world.events.entityHit.subscribe(hitEnt => {
  let hit = hitEnt.hitEntity;
  let entity = hitEnt.entity;
  let inventory = entity.getComponent("inventory");
  let container = inventory.container;
  let hand = container.getItem(entity.selectedSlot);

  if(entity.id == "minecraft:player" && hit.id == "new:tumba" && hit.nameTag == entity.nameTag && hand){
    if(hand.id == "new:key"){
      hit.runCommand(`event entity @s new:entity_death`);
      entity.runCommand(`clear @s new:key 0 1`);
    }
    if(hand.id == "new:key2"){
      hit.runCommand(`event entity @s new:entity_death`);
      entity.runCommand(`clear @s new:key2 0 1`);
    }
  } 
  else if(hit.nameTag != entity.nameTag){
    if(hand.id == "new:key2" || hand.id == "new:key"){
      entity.runCommand(`tellraw @s {"rawtext":[{"translate":"action.players.warn"},{"text":"${hit.nameTag}"}]}`)
    }
  }
});

//Comando Custom
let prefix = "&";
world.events.beforeChat.subscribe(e => {
  let msg = e.message;
  if (msg.startsWith(prefix)) {
    let args = msg.slice(prefix.length).split(" ");
    let cmd = args.shift().toLowerCase();
    let subCmd = args[0];
    if (cmd == "key" && subCmd == "enchanted" && activeCommand == true) {
      e.cancel = true;
      world.getDimension("overworld").runCommand(`clear @a[name="${e.sender.name}"] new:key2 0 1`);
      world.getDimension("overworld").runCommand(`clear @a[name="${e.sender.name}"] minecraft:ender_pearl 0 1`);
      world.getDimension("overworld").runCommand(`give @a[name="${e.sender.name}"] new:key 1 0 ${JSON.stringify(giveConfig)}`);
    }  
  }
});


//Functiones de deteccion de inventario
function getItems(inventory) {
  let items = [];
  if (inventory.size) {
    for (let i = 0; i < inventory.size; i++) {
      items.push(inventory.getItem(i));
    }
  } 
  else if (!inventory.size && inventory.container) {
    for (let i = 0; i < inventory.container.size; i++) {
      items.push(inventory.container.getItem(i));
    }
  }
  return items;
}
function findItem(items, item) {
  try {
    let res;
    if (item.amount == '*') {
      res = items.filter(it => it && item.id == it.id);
    } 
    else {
      res = items.filter(it => it && item.id == it.id && item.amount == it.amount);
    }
    return res.length > 0 ? items.indexOf(res[0]) : -1;
  } 
  catch (e) {}
}