import { world, BlockLocation, system } from "@minecraft/server"

let worldPlayer = [];

system.events.beforeWatchdogTerminate.subscribe(({ cancel }) => { cancel = true })

world.events.tick.subscribe(t => {
    if (t.currentTick % 5 === 0) {
        for (const players of world.getPlayers()) {
            if (worldPlayer.find(object => { return object.playerName === players.name})){
            }
            else {
                worldPlayer.push({ playerName: players.name, idBlock: '', logBlocks: [], otherBlocks: [], logCount: 1, otherCount: 0 })
            }
        }
    }
    if (t.currentTick % 2 === 0) {
        for (let i = 0; i < worldPlayer.length; i++) {
            if(worldPlayer[i].logCount >= 128){
                worldPlayer[i] = { playerName: worldPlayer[i].playerName, idBlock: '', logBlocks: [], otherBlocks: [], logCount: 1, otherCount: 0 }
                world.getDimension("overworld").runCommandAsync(`title @a actionbar §fMax 128 blocks`)
            }
            else if (worldPlayer[i].logBlocks[0] || worldPlayer[i].otherBlocks[0]) {
                if(worldPlayer[i].logBlocks[0]){
                    function callsSpeed(Num) {
                        for (let ti = 0; ti < Num; ti++) {
                            treeDestroy(i,worldPlayer[i].idBlock,worldPlayer[i].logBlocks)
                        }
                    }
                    callsSpeed(5);
                }
                if(worldPlayer[i].otherBlocks[0]){
                    function callsSpeed(Num) {
                        for (let ti = 0; ti < Num; ti++) {
                            treeDestroy(i,worldPlayer[i].idBlock,worldPlayer[i].otherBlocks)
                        }
                    }
                    callsSpeed(78);
                }
            }
            else {
                worldPlayer[i] = { playerName: worldPlayer[i].playerName, idBlock: '', logBlocks: [], otherBlocks: [], logCount: 1, otherCount: 0 }
            }
        }
    }
})

world.events.blockBreak.subscribe(f => {
    const player = f.player
    try {
        if (player.getComponent("inventory").container.getItem(player.selectedSlot).typeId.includes("axe")) {
            const blockId = f.brokenBlockPermutation.type.id
            const xyz = f.block.location
            if ((blockId.includes('log') && !blockId.includes('stripped')) && f.dimension.getBlock(new BlockLocation(xyz.x, xyz.y+1, xyz.z)).typeId == blockId) {
                for (let i = 0; i < worldPlayer.length; i++) {
                    if(worldPlayer[i].playerName == player.name){
                        worldPlayer[i].logBlocks.push(`${xyz.x} ${xyz.y+1} ${xyz.z}`)
                        worldPlayer[i].idBlock = blockId
                    }
                }
            }
        }
    } catch (e) { }
    
})
function treecapitator(block,x,y,z,player) {
    try {
        const blockSides = [ [x,y-1,z], [x+1,y,z], [x,y,z-1], [x-1,y,z], [x,y,z+1], [x,y+1,z], [x+1,y+1,z+1], [x+1,y+1,z-1], [x-1,y+1,z-1], [x-1,y+1,z+1] ]
        for (const coords of blockSides) {
            const idBlocks = world.getDimension("overworld").getBlock(new BlockLocation(coords[0],coords[1],coords[2])).typeId
            if(idBlocks == block && worldPlayer[player].logCount < 128){
                if (worldPlayer[player].logBlocks.every(l => l != `${coords[0]} ${coords[1]} ${coords[2]}`)) {
                    worldPlayer[player].logBlocks.push(`${coords[0]} ${coords[1]} ${coords[2]}`)
                    worldPlayer[player].logCount+=1
                }
            }
            if((idBlocks.includes('leaves') || idBlocks.includes('vine')) && (worldPlayer[player].otherCount < worldPlayer[player].logCount *6 && worldPlayer[player].otherCount < 390)){
                if (worldPlayer[player].otherBlocks.every(o => o != `${coords[0]} ${coords[1]} ${coords[2]}`)) {
                    worldPlayer[player].otherBlocks.push(`${coords[0]} ${coords[1]} ${coords[2]}`)
                    worldPlayer[player].otherCount+=1
                }
            }
        }
    } catch (e) {
        //world.getDimension("overworld").runCommand(`say ${e}`)
    }
}
function treeDestroy(player,block,blockList) {
    try {
    if (worldPlayer[player].logBlocks[0] || worldPlayer[player].otherBlocks[0]) {
            const x = Number(blockList[0].slice(0,blockList[0].indexOf(' ')))
            const y = Number(blockList[0].slice(blockList[0].indexOf(' '),blockList[0].indexOf(' ',blockList[0].indexOf(' ')+1)))
            const z = Number(blockList[0].slice(blockList[0].indexOf(' ',blockList[0].indexOf(' ')+1)))
            //world.getDimension("overworld").runCommandAsync(`title ${worldPlayer[player].playerName} actionbar ${block} ${worldPlayer[player].logCount} : ${worldPlayer[player].otherCount} - ${x} ${y} ${z} - Index Player: ${player}`)
            treecapitator(block,x,y,z,player)
        }
        world.getDimension("overworld").runCommandAsync(`setblock ${blockList.splice(0,1)} air 0 destroy`)
    } catch (e) {}
}