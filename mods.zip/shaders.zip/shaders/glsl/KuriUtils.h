vec3 tonemapFilmic(vec3 ccolor) {
				vec3 x = max(vec3(0.0, 0.0, 0.0), ccolor - 0.004);
				return (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);
			}

vec3 HDRFilter(vec3 color, float contrast, float overExpose, float underExpose) { 

vec3 overExposed = color / overExpose; 
vec3 normalExposed = color; 
vec3 underExposed = color * underExpose; 

color = mix(overExposed, underExposed, normalExposed); color = ((color - vec3(0.5)) * max(contrast, 0.0)) + 0.5;

return color;}

vec3 unchartedTonemap(vec3 x){
				vec3 A = vec3(0.15, 0.15, 0.15);
				vec3 B = vec3(0.50, 0.50, 0.50);
				vec3 C = vec3(0.10, 0.10, 0.10);
				vec3 D = vec3(0.20, 0.20, 0.20);
				vec3 E = vec3(0.02, 0.02, 0.02);
				vec3 F = vec3(0.30, 0.30, 0.30);
				return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
			}

			vec3 unchartedTonemapTwo(vec3 c){
				float W = 11.2;
				vec3 exposureBias = vec3(2.0, 2.0, 2.0);
				vec3 curr = unchartedTonemap(exposureBias * c);
				vec3 whiteScale = vec3(1.0, 1.0, 1.0) / unchartedTonemap(vec3(W, W, W));
				return curr * whiteScale;
			}


vec3 acesFilm(vec3 x) {
			    const float a = 2.51;
			    const float b = 0.03;
			    const float c = 2.43;
			    const float d = 0.59;
			    const float e = 0.14;
			    return clamp((x * (a * x + b)) / (x * (c * x + d ) + e), vec3(0.0, 0.0, 0.0), vec3(1.0, 1.0, 1.0));
			}
			
vec3 day_light = vec3(1.0,1.0,1.0);
vec3 moon_Color = vec3(0.040, 0.07, 0.09)*0.15;
vec3 sun_Sunset = vec3(0.6,0.3,0.0);

vec4 moonLight(vec4 light, float null){

float amount = 1.0;
float colorDesat = dot(light.rgb, vec3(9.9));
float test = 1.0;

light.rgb = mix(light.rgb, vec3(colorDesat) * moon_Color, amount * null);

return light;}

vec4 dayLight(vec4 light, float null){

vec4 lum_day = light * vec4(vec3(day_light), 1.0);
vec4 final_day = lum_day;

return final_day;}

vec4 sunLight(vec4 light, float null){

float sunset = (light.r + light.g + light.b) / 1.5;

return mix( light, vec4 (sunset * sun_Sunset.r, sunset * sun_Sunset.g, sunset * sun_Sunset.b, light.a), null);}

vec4 lightMap(vec4 light, vec2 curr, float setLight){

float notlight = (1.0 - curr.x);
float day = curr.y * 0.75 * setLight;
float sun = (0.5-abs(0.5-setLight))*notlight*curr.y;
float night = curr.y * notlight *0.95*(1.0-setLight);

return sunLight(dayLight(moonLight(light,night),day),sun);}