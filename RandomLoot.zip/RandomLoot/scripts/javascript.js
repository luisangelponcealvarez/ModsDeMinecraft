import { world } from '@minecraft/server'

world.events.entityHurt.subscribe(e => {
    try {
	const { x, y, z } = e.hurtEntity.location
	    if (e.hurtEntity.getComponent('minecraft:health').current <= 0 && e.damagingEntity) {
	        e.hurtEntity.runCommandAsync(`execute @s ~~~ loot spawn ${x} ${y} ${z} loot "${Math.floor(Math.random()*230+1)}"`)
	    }
    } catch (e) {}
})